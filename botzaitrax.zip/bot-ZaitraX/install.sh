pkg install git
pkg install wget
pkg install ffmpeg
pkg install nodejs
apt update && apt upgrade
git clone https://github.com/ZaitraX/botzaitrax
cd botzaitrax
npm i -g cwebp
npm i -g ytdl 
npm i
npm i got
node index.js